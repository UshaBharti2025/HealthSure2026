<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<%@ taglib prefix="f" uri="http://java.sun.com/jsf/core"%>
<%@ taglib prefix="h" uri="http://java.sun.com/jsf/html"%>

<f:view>
	<!DOCTYPE html>
	<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Signup</title>
<link rel="stylesheet"
	href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
<link rel="stylesheet" href="/HealthSureClient/resources/css/auth/Signup.css" />
<script>
    // Global variables for timer management
    let resendTimer;
    let lastOtpTimestamp = 0;
    let resendAttempts = 0;
    let blockedUntil = 0;
    let isBlocked = false;

    // SVG icons as strings
    const showIcon = `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-eye"><path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/></svg>`;
    const hideIcon = `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-eye-off"><path d="M9.88 9.88a3 3 0 1 0 4.24 4.24"/><path d="M10.73 5.08A10.43 10.43 0 0 1 12 5c7 0 10 7 10 7a13.16 13.16 0 0 1-1.67 2.68"/><path d="M6.61 6.61A13.52 13.52 0 0 0 2 12s3 7 10 7a9.75 9.75 0 0 0 5.39-1.61"/><line x1="2" x2="22" y1="2" y2="22"/></svg>`;
    const userIcon = `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-user"><path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>`;
    const lockIcon = `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-lock"><rect width="18" height="11" x="3" y="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>`;
    const keyIcon = `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-key"><path d="m21 2-2 2m-7.61 7.61a5.5 5.5 0 1 1-7.778 7.778 5.5 5.5 0 0 1 7.778-7.778z"/><path d="m15.5 5.5 4 4"/></svg>`;

    // Function to toggle the password visibility
    function togglePasswordVisibility(inputFieldId, button) {
        var input = document.getElementById(inputFieldId);
        if (input.type === "password") {
            input.type = "text";
            button.innerHTML = hideIcon;
        } else {
            input.type = "password";
            button.innerHTML = showIcon;
        }
    }
    
    // Function to initialize values from hidden fields
    function initializeValues() {
        try {
            const lastOtpEl = document.getElementById('lastOtpTimestamp');
            const attemptsEl = document.getElementById('resendAttempts');
            const blockedEl = document.getElementById('otpBlockedUntil');
            
            if (lastOtpEl) lastOtpTimestamp = parseInt(lastOtpEl.value) || 0;
            if (attemptsEl) resendAttempts = parseInt(attemptsEl.value) || 0;
            if (blockedEl) blockedUntil = parseInt(blockedEl.value) || 0;
            
            isBlocked = blockedUntil > new Date().getTime();
        } catch (e) {
            console.error("Error initializing OTP values:", e);
        }
    }
    
    function formatTime(num) {
        return num < 10 ? '0' + num : num;
    }
    
    function startCountdown() {
        const button = document.getElementById('resendOtpBtn');
        const countdownContainer = document.getElementById('countdownContainer');
        const timerDisplay = document.getElementById('timerDisplay');
        
        if (!button || !countdownContainer || !timerDisplay) return;
        
        if (resendTimer) clearInterval(resendTimer);
        
        if (isBlocked) {
            startBlockCountdown(blockedUntil - new Date().getTime());
            return;
        }
        
        const now = new Date().getTime();
        const cooldownEnd = lastOtpTimestamp + 30000;
        let remaining = Math.max(0, cooldownEnd - now);
        
        if (remaining > 0) {
            button.disabled = true;
            countdownContainer.classList.remove('hidden');
            button.classList.add('disabled-btn');
            button.classList.remove('pulse-animation', 'hover-effect');
            
            updateTimerDisplay(timerDisplay, remaining);
            
            resendTimer = setInterval(function() {
                remaining -= 1000;
                updateTimerDisplay(timerDisplay, remaining);
                
                if (remaining <= 0) {
                    clearInterval(resendTimer);
                    enableResendButton();
                }
            }, 1000);
        } else {
            enableResendButton();
        }
    }
    
    function startBlockCountdown(blockDuration) {
        const button = document.getElementById('resendOtpBtn');
        const countdownContainer = document.getElementById('countdownContainer');
        const timerDisplay = document.getElementById('timerDisplay');
        
        if (!button || !countdownContainer || !timerDisplay) return;
        
        button.disabled = true;
        countdownContainer.classList.remove('hidden');
        button.classList.add('disabled-btn');
        button.classList.remove('pulse-animation', 'hover-effect');
        
        const minutes = Math.floor(blockDuration / 60000);
        const seconds = Math.floor((blockDuration % 60000) / 1000);
        timerDisplay.textContent = formatTime(minutes) + ":" + formatTime(seconds);
        
        resendTimer = setInterval(function() {
            blockDuration -= 1000;
            
            if (blockDuration <= 0) {
                clearInterval(resendTimer);
                isBlocked = false;
                startCountdown();
            } else {
                const minutes = Math.floor(blockDuration / 60000);
                const seconds = Math.floor((blockDuration % 60000) / 1000);
                timerDisplay.textContent = formatTime(minutes) + ":" + formatTime(seconds);
            }
        }, 1000);
    }
    
    function updateTimerDisplay(timerDisplay, remainingMs) {
        const seconds = Math.ceil(remainingMs / 1000);
        timerDisplay.textContent = formatTime(seconds);
    }
    
    function enableResendButton() {
        const button = document.getElementById('resendOtpBtn');
        const countdownContainer = document.getElementById('countdownContainer');
        
        if (!button || !countdownContainer) return;
        
        button.disabled = false;
        countdownContainer.classList.add('hidden');
        button.classList.remove('disabled-btn');
        button.classList.add('pulse-animation', 'hover-effect');
    }
    
    document.addEventListener('DOMContentLoaded', function() {
        initializeValues();
        
        const urlParams = new URLSearchParams(window.location.search);
        if (urlParams.has('error')) {
            const errorMsg = decodeURIComponent(urlParams.get('error'));
            console.error("OTP Error:", errorMsg);
        }

        if (document.getElementById('resendOtpBtn')) {
            startCountdown();
        }
        
        if (isBlocked) {
            const button = document.getElementById('resendOtpBtn');
            const countdownContainer = document.getElementById('countdownContainer');
            if (button && countdownContainer) {
                button.disabled = true;
                button.classList.remove('pulse-animation', 'hover-effect');
                countdownContainer.classList.remove('hidden');
            }
        }
    });

    document.forms[0]?.addEventListener('submit', function(e) {
        const resendBtn = document.getElementById('resendOtpBtn');
        if (resendBtn && resendBtn.disabled) {
            e.preventDefault();
            console.warn("Please wait before requesting another OTP.");
            return false;
        }
        return true;
    });

    // New JavaScript function for the back button
    function goBackAndReset() {
        // Find the JSF form by its ID
        const form = document.getElementById('signup');
        if (form) {
            // Get all input fields within the form
            const inputs = form.querySelectorAll('input');
            inputs.forEach(input => {
                // Reset the value of each input field
                input.value = '';
            });
            
            // Re-enable the input fields that were disabled
            const disabledInputs = form.querySelectorAll('[disabled]');
            disabledInputs.forEach(input => {
                input.disabled = false;
            });

            // Redirect to the same page without any parameters to reset the state
            window.location.href = window.location.pathname;
        }
    }
</script>
<script >

window.addEventListener("beforeunload", function (e) { document.getElementById("signup").reset();

});
function backReset(){
	document.getElementById("signup").reset();
}
</script>
 
</head>
<body class="signup-page">

	<div class="signup-container animate_animated animate_fadeIn">
		<h:form styleClass="signup-card" prependId="false" id="signup">

			<h:inputHidden id="lastOtpTimestamp"
				value="#{adminController.lastOtpTimestamp}" />
			<h:inputHidden id="resendAttempts"
				value="#{adminController.resendAttempts}" />
			<h:inputHidden id="otpBlockedUntil"
				value="#{adminController.otpBlockedUntil}" />
			<div class="heading-container">
				<h2 class="form-title">Admin Signup</h2>
			</div>

			<div class="form-grid">
				<div class="form-group">
					<h:outputLabel for="firstName" value="First Name"
						styleClass="form-label" />
					<div class="input-with-icon">
						<div class="input-icon">
							<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-user"><path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
						</div>
						<h:inputText id="firstName"
							value="#{adminController.user.firstName}"
							disabled="#{adminController.otpSent}" styleClass="form-input icon-input" />
					</div>
					<h:message for="firstName" styleClass="error-message" />
				</div>

				<div class="form-group">
					<h:outputLabel for="lastName" value="Last Name"
						styleClass="form-label" />
					<div class="input-with-icon">
						<div class="input-icon">
							<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-user"><path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
						</div>
						<h:inputText id="lastName" value="#{adminController.user.lastName}"
							disabled="#{adminController.otpSent}" styleClass="form-input icon-input" />
					</div>
					<h:message for="lastName" styleClass="error-message" />
				</div>

				<div class="form-group">
					<h:outputLabel for="username" value="Username"
						styleClass="form-label" />
					<div class="input-with-icon">
						<div class="input-icon">
							<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-user"><path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
						</div>
						<h:inputText id="username" value="#{adminController.user.username}"
							disabled="#{adminController.otpSent}" styleClass="form-input icon-input" />
					</div>
					<h:message for="username" styleClass="error-message" />
				</div>

				<div class="password-toggle-container form-group">
					<h:outputLabel for="password" value="Password"
						styleClass="form-label" />
					<div class="input-with-icon">
						<div class="input-icon">
							<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-lock"><rect width="18" height="11" x="3" y="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
						</div>
						<h:inputSecret id="password"
							value="#{adminController.user.password}"
							disabled="#{adminController.otpSent}" styleClass="form-input icon-input" />
					</div>
					<button type="button" class="password-toggle-btn"
						onclick="togglePasswordVisibility('password', this)">
						<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-eye"><path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/></svg>
					</button>
					<h:message for="password" styleClass="error-message" />
				</div>

				<div class="form-group full-width">
					<h:outputLabel for="email" value="Email" styleClass="form-label" />
					<div class="input-with-icon">
						<div class="input-icon">
							<svg class="h-5 w-5 text-gray-400"
								xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"
								fill="currentColor">
                                <path
									d="M2.003 5.884L10 9.882l7.997-3.998A2 2 0 0016 4H4a2 2 0 00-1.997 1.884z" />
                                <path
									d="M18 8.118l-8 4-8-4V14a2 2 0 002 2h12a2 2 0 002-2V8.118z" />
                            </svg>
						</div>
						<h:inputText id="email" value="#{adminController.user.email}"
							disabled="#{adminController.otpSent}"
							styleClass="form-input icon-input" />
					</div>
					<h:message for="email" styleClass="error-message" />
				</div>
			</div>

			<h:commandButton value="Send OTP"
				action="#{adminController.sendOtpToEmail}"
				rendered="#{!adminController.otpSent}" styleClass="btn btn-primary" />

			<h:panelGroup rendered="#{adminController.otpSent}">
				<div class="otp-section animate_animated animate_fadeInUp">
					<div class="form-group">
						<h:outputLabel for="otp" value="Verification Code"
							styleClass="form-label" />
						<div class="input-with-icon">
							<div class="input-icon">
								<svg class="h-5 w-5 text-gray-400"
									xmlns="http://www.w3.org/2000/svg" fill="none"
									viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round"
										stroke-linejoin="round" stroke-width="2"
										d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                                </svg>
							</div>
							<h:inputText id="otp" value="#{adminController.otp}"
								styleClass="form-input icon-input" />
						</div>
						<h:message for="otp" styleClass="error-message" />
						<p class="input-help-text">We've sent a 6-digit code to your
							email</p>
					</div>

					<div class="button-group">
						<h:commandButton value="Verify & Register"
							action="#{adminController.verifyOtpAndSignUp}"
							styleClass="btn btn-primary" />

						<h:commandButton id="resendOtpBtn" value="Resend OTP"
							action="#{adminController.resendOtp}"
							styleClass="btn btn-secondary pulse-animation hover-effect">
							<f:param name="action" value="resendOtp" />
						</h:commandButton>
					</div>
					
					<div class="countdown-message-container" id="countdownContainer">
						<div class="countdown-container">
							<span class="countdown-text">Resend OTP available in</span> <span
								id="timerDisplay" class="countdown-timer">30</span>
						</div>
					</div>
				</div>
			</h:panelGroup>

			<div id="messageContainer" class="global-message-container">
				<h:messages globalOnly="true" layout="table"
					styleClass="global-message animate_animated animate_fadeIn"
					id="message" />
			</div>

		</h:form>
        
          <!-- NEW CONTAINER FOR BACK BUTTON -->
		<div class="back-button-container">
            <!-- Updated to use a plain HTML link to bypass JSF form submission -->
            <h:form>
                <h:commandButton value="Back" onclick="backReset();" action="#{adminController.Signupback}" styleClass="btn-secondary full-width" />
            </h:form>
		</div>
	
	</div>
</body>
	</html>
</f:view>
