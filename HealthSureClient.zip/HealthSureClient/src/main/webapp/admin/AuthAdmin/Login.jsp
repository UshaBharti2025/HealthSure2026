<!--
  Copyright © 2025 Infinite Computer Solution. All rights reserved.

  @Author: Infinite Computer Solutions

  Description: JSF Admin Dashboard Page having administrative controls.
-->
<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<%@ taglib prefix="f" uri="http://java.sun.com/jsf/core"%>
<%@ taglib prefix="h" uri="http://java.sun.com/jsf/html"%>

<f:view>
	<!DOCTYPE html>
	<html>
<head>
<meta charset="UTF-8">
<title>Login</title>

<meta http-equiv="Cache-Control"
	content="no-cache, no-store, must-revalidate" />
<meta http-equiv="Pragma" content="no-cache" />
<meta http-equiv="Expires" content="0" />
<link rel="stylesheet"
	href="/HealthSureClient/resources/css/auth/Login.css" />
	<script >

window.addEventListener("beforeunload", function (e) { document.getElementById("login").reset();

});
</script>
 
</head>
<body class="login-container">

	<div class="login-container">

		<div class="login-card">

			<div class="login-card__left-section">

				<div class="left-section__header"
					style="background-image: url('https://as2.ftcdn.net/v2/jpg/02/60/04/09/1000_F_260040900_oO6YW1sHTnKxby4GcjCvtypUCWjnQRg5.jpg');">
					<div class="header__content">
						<h1 class="header__title">Welcome Back!</h1>
						<p class="header__subtitle">To Admin Portal</p>
					</div>
				</div>

				<div class="left-section__message">
					<div class="message__card">
						<p class="message__text">
							Your trusted partner<br /> in <span
								class="message__text-highlight-yellow">health</span> and <span
								class="message__text-highlight-green">wellness</span>.
						</p>
					</div>
				</div>
			</div>

			<div class="login-card__right-section">

				<div class="form__header">
					<h2 class="form__header-title">HealthSure</h2>
					<h2 class="form__header-subtitle">Login</h2>
				</div>

				<div class="form__container">
					<h:form styleClass="form__fields-list" prependId="false" id="login">

						<div class="form-group">
							<h:outputLabel for="username" value="Username or Email:"
								styleClass="form-group__label" />
							<h:inputText id="username"
								value="#{adminController.loginUser.username}"
								styleClass="input-field" />
							<h:message for="username" styleClass="form-group__message" />
						</div>

						<div class="password-toggle-container form-group">
							<h:outputLabel for="password" value="Password:"
								styleClass="form-group__label" />
							<h:inputSecret id="password"
								value="#{adminController.loginUser.password}"
								styleClass="input-field" redisplay="true" />
							<button type="button" class="password-toggle-btn"
								onclick="togglePasswordVisibility('password', this)">
								<!-- Initial show icon -->
								<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"
									viewBox="0 0 24 24" fill="none" stroke="currentColor"
									stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
									class="lucide lucide-eye">
									<path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z" />
									<circle cx="12" cy="12" r="3" /></svg>
							</button>
							<h:message for="password" styleClass="form-group__message" />
						</div>

						<div class="forgot-password-link-container">
							<h:outputLink value="../../ForgetPassword.jsf"
								styleClass="forgot-password-link">
                Forget Password
              </h:outputLink>
						</div>

						<h:commandButton value="Login" action="#{adminController.login}"
							styleClass="login-button" />

						<h:messages globalOnly="true" layout="table"
							styleClass="global-messages" />

					</h:form>
				</div>
			</div>
		</div>
	</div>

	<script>
		// SVG icons as strings
		const showIcon = `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-eye"><path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/></svg>`;
		const hideIcon = `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-eye-off"><path d="M9.88 9.88a3 3 0 1 0 4.24 4.24"/><path d="M10.73 5.08A10.43 10.43 0 0 1 12 5c7 0 10 7 10 7a13.16 13.16 0 0 1-1.67 2.68"/><path d="M6.61 6.61A13.52 13.52 0 0 0 2 12s3 7 10 7a9.75 9.75 0 0 0 5.39-1.61"/><line x1="2" x2="22" y1="2" y2="22"/></svg>`;

		// Function to toggle the password visibility
		function togglePasswordVisibility(inputFieldId, button) {
			var input = document.getElementById(inputFieldId);
			if (input.type === "password") {
				input.type = "text";
				button.innerHTML = hideIcon;
			} else {
				input.type = "password";
				button.innerHTML = showIcon;
			}
		}
	</script>

</body>
	</html>
</f:view>
